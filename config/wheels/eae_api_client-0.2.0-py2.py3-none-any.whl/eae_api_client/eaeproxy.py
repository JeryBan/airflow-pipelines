import json
from urllib.parse import urlparse, urlunparse

import requests
from django.http import HttpRequest, HttpResponse
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django.views.generic.base import View


@method_decorator(csrf_exempt, name="dispatch")
class EaeProxyView(View):
    @classmethod
    def as_view(cls, **initkwargs) -> callable:
        cls.eae_backend_url = initkwargs.pop("eae_backend_url").rstrip("/")
        return super().as_view(**initkwargs)

    def dispatch(self, request: HttpRequest, *args, **kwargs) -> HttpResponse:
        eae_response = None
        try:
            eae_response = requests.request(
                self.request.method,
                f"{self.eae_backend_url}{self.request.path}",
                headers=self._get_headers(),
                params=self.request.GET,
                data=self.request,
            )
            eae_response.raise_for_status()
            data = eae_response.json()
        except (requests.RequestException, requests.JSONDecodeError) as e:
            return self._get_error_response(eae_response, e)
        self._modify_eae_response(data)
        return HttpResponse(json.dumps(data), content_type="application/json")

    def _get_headers(self) -> dict:
        headers = {
            h: self.request.headers[h]
            for h in ("Authorization", "Content-Type")
            if h in self.request.headers
        }
        headers["User-Agent"] = "Cognitera EaeProxy"
        headers["Accept"] = "application/json"
        return headers

    def _get_error_response(self, eae_response, exception) -> dict:
        if eae_response is None or not hasattr(eae_response, "status_code"):
            status = 502
            msg = str(exception)
        else:
            msg = f"Ο server απάντησε: {eae_response.content.decode('utf8')}"
            if eae_response.status_code < 400:
                # The problem was probably in decoding JSON
                status = 502
            else:
                status = eae_response.status_code
        msg = f"Παρουσιάστηκε σφάλμα κατά την επικοινωνία με το server της EAE. {msg}"
        return HttpResponse(
            json.dumps({"detail": msg}, ensure_ascii=False).encode("utf8"),
            status=status,
            content_type="application/json",
            charset="utf-8",
        )

    def _modify_eae_response(self, data: dict) -> None:
        keys = data.keys()
        if len(keys) != 4 or set(keys) != {"count", "next", "previous", "results"}:
            return
        if data["next"]:
            data["next"] = self._get_modified_url(data["next"])
        if data["previous"]:
            data["previous"] = self._get_modified_url(data["previous"])

    def _get_modified_url(self, url: str) -> str:
        url_components = list(urlparse(url))
        url_components[0] = self.request.scheme
        url_components[1] = self.request.get_host()
        return urlunparse(url_components)

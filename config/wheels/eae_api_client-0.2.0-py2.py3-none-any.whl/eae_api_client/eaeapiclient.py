import requests


class EaeApiClient:
    def __init__(self, eae_backend_url: str, token: str = None) -> None:
        self.eae_backend_url = eae_backend_url.rstrip("/")
        self.token = token

    def login(self, username: str, password: str, endpoint: str = None) -> None:
        if endpoint in ("auth", "external-auth"):
            self._login_in_specific_endpoint(username, password, endpoint)
        elif endpoint is None:
            self._login_in_both_endpoints(username, password)
        else:
            raise ValueError(f'{endpoint} is not a valid value for "endpoint"')

    def _login_in_specific_endpoint(self, username, password, endpoint) -> None:
        response = requests.post(
            f"{self.eae_backend_url}/eae/api/v1/{endpoint}/login/",
            json={"username": username, "password": password},
        )
        response.raise_for_status()
        self.token = response.json()["token"]

    def _login_in_both_endpoints(self, username, password):
        try:
            self._login_in_specific_endpoint(username, password, "external-auth")
            return
        except requests.exceptions.HTTPError as e:
            if e.response.status_code != 401:
                raise
        self._login_in_specific_endpoint(username, password, "auth")

    def get_item(self, app: str, endpoint: str, **params) -> dict:
        app = app.strip("/")
        endpoint = endpoint.strip("/")
        url = f"{self.eae_backend_url}/{app}/api/v1/{endpoint}/"
        response = requests.get(url, headers=self._get_headers(), params=params)
        response.raise_for_status()
        return response.json()

    def get_list(self, app: str, endpoint: str, **params) -> list:
        app = app.strip("/")
        endpoint = endpoint.strip("/")
        result = []
        while True:
            results_page = self._get_list_page_from_eae(app, endpoint, **params)
            result.extend(results_page)
            if not self._next_page:
                break
        return result

    def _get_list_page_from_eae(self, app: str, endpoint: str, **params) -> tuple:
        if getattr(self, "_next_page", None):
            assert (app in self._next_page) and (endpoint in self._next_page)
            url = self._next_page
        else:
            url = f"{self.eae_backend_url}/{app}/api/v1/{endpoint}/"

        response = requests.get(url, headers=self._get_headers(), params=params)
        response.raise_for_status()
        response_dict = response.json()
        self._next_page = response_dict["next"]
        return response_dict["results"]

    def _get_headers(self) -> dict:
        if self.token:
            return {"Authorization": f"bearer {self.token}"}
        return {}

    def put(self, app: str, endpoint: str, **kwargs) -> dict:
        app = app.strip("/")
        endpoint = endpoint.strip("/")
        url = f"{self.eae_backend_url}/{app}/api/v1/{endpoint}/"
        response = requests.put(url, headers=self._get_headers(), **kwargs)
        response.raise_for_status()
        return response.json()

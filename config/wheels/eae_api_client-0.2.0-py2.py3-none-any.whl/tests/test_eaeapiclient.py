from unittest import TestCase
from unittest.mock import call, patch

import requests

from eae_api_client import EaeApiClient


@patch("eae_api_client.eaeapiclient.requests.post")
class LoginTestCase(TestCase):
    def setUp(self):
        self.eae_api_client = EaeApiClient("https://mydomain.com")

    def test_makes_post_request(self, m):
        self.eae_api_client.login("joe", "topsecret", endpoint="auth")
        m.assert_called_once_with(
            "https://mydomain.com/eae/api/v1/auth/login/",
            json={"username": "joe", "password": "topsecret"},
        )

    def test_raises_on_error(self, m):
        m.return_value.raise_for_status.side_effect = requests.RequestException()
        with self.assertRaises(requests.RequestException):
            self.eae_api_client.login("joe", "topsecret", endpoint="auth")

    def test_sets_token(self, m):
        m.return_value.json.return_value = {
            "created_at": "2023-06-12T14:58:10.908230Z",
            "expires_in": "6986.297365",
            "token": "topsecret-token",
        }
        self.eae_api_client.login("joe", "topsecret", endpoint="auth")
        self.assertEqual(self.eae_api_client.token, "topsecret-token")

    def test_uses_external_auth_if_requested(self, m):
        self.eae_api_client.login("joe", "topsecret", endpoint="external-auth")
        m.assert_called_once_with(
            "https://mydomain.com/eae/api/v1/external-auth/login/",
            json={"username": "joe", "password": "topsecret"},
        )

    def test_uses_external_auth_if_endpoint_unspecified(self, m):
        self.eae_api_client.login("joe", "topsecret")
        m.assert_called_once_with(
            "https://mydomain.com/eae/api/v1/external-auth/login/",
            json={"username": "joe", "password": "topsecret"},
        )

    def test_uses_both_endpoints_if_first_one_refuses(self, m):
        error = requests.exceptions.HTTPError()
        error.response = requests.Response()
        error.response.status_code = 401
        m.return_value.raise_for_status.side_effect = [error, None]
        self.eae_api_client.login("joe", "topsecret")
        self.assertEqual(
            m.call_args_list,
            [
                call(
                    "https://mydomain.com/eae/api/v1/external-auth/login/",
                    json={"username": "joe", "password": "topsecret"},
                ),
                call(
                    "https://mydomain.com/eae/api/v1/auth/login/",
                    json={"username": "joe", "password": "topsecret"},
                ),
            ],
        )

    def test_does_not_proceed_to_second_endpoint_if_first_one_errs(self, m):
        error = requests.exceptions.HTTPError()
        error.response = requests.Response()
        error.response.status_code = 501
        m.return_value.raise_for_status.side_effect = error
        with self.assertRaises(requests.exceptions.HTTPError):
            self.eae_api_client.login("joe", "topsecret")
        self.assertEqual(
            m.call_args_list,
            [
                call(
                    "https://mydomain.com/eae/api/v1/external-auth/login/",
                    json={"username": "joe", "password": "topsecret"},
                ),
            ],
        )

    def test_does_not_proceed_to_second_endpoint_if_first_one_timeout(self, m):
        m.return_value.raise_for_status.side_effect = requests.RequestException
        with self.assertRaises(requests.RequestException):
            self.eae_api_client.login("joe", "topsecret")
        self.assertEqual(
            m.call_args_list,
            [
                call(
                    "https://mydomain.com/eae/api/v1/external-auth/login/",
                    json={"username": "joe", "password": "topsecret"},
                ),
            ],
        )


@patch("eae_api_client.eaeapiclient.requests.get")
class GetListTestCase(TestCase):
    def setUp(self):
        self.eae_api_client = EaeApiClient("https://mydomain.com")

    def test_returns_correct_result(self, m):
        m.return_value.json.return_value = {"next": None, "results": [42, 24]}
        mylist = self.eae_api_client.get_list("myapp", "myendpoint")
        self.assertEqual(mylist, [42, 24])

    def test_makes_get_request(self, m):
        m.return_value.json.return_value = {"next": None, "results": [42, 24]}
        self.eae_api_client.get_list("myapp", "myendpoint")
        m.assert_called_once_with(
            "https://mydomain.com/myapp/api/v1/myendpoint/", headers={}, params={}
        )

    def test_raises_on_error(self, m):
        m.return_value.raise_for_status.side_effect = requests.RequestException()
        with self.assertRaises(requests.RequestException):
            self.eae_api_client.get_list("myapp", "myendpoint")

    def test_includes_authorization_header(self, m):
        m.return_value.json.return_value = {"next": None, "results": [42, 24]}
        self.eae_api_client.token = "topsecret"
        self.eae_api_client.get_list("myapp", "myendpoint")
        m.assert_called_once_with(
            "https://mydomain.com/myapp/api/v1/myendpoint/",
            headers={"Authorization": "token topsecret"},
            params={},
        )

    def _get_paginated_results(self, m):
        m.return_value.json.side_effect = [
            {
                "next": "https://mydomain.com/myapp/api/v1/myendpoint/?page=2",
                "results": [42, 24],
            },
            {"next": None, "results": [56, 65]},
        ]
        return self.eae_api_client.get_list("myapp", "myendpoint")

    def test_returns_correct_result_from_pagination(self, m):
        mylist = self._get_paginated_results(m)
        self.assertEqual(mylist, [42, 24, 56, 65])

    def test_makes_get_requests_for_paginated_results(self, m):
        self._get_paginated_results(m)
        self.assertEqual(
            m.call_args_list,
            [
                call(
                    "https://mydomain.com/myapp/api/v1/myendpoint/",
                    headers={},
                    params={},
                ),
                call(
                    "https://mydomain.com/myapp/api/v1/myendpoint/?page=2",
                    headers={},
                    params={},
                ),
            ],
        )


@patch("eae_api_client.eaeapiclient.requests.get")
class UrlSanitizationTestCase(TestCase):
    def test_removes_trailing_slashes_from_eae_backend_url(self, m):
        client = EaeApiClient("https://my.domain.com//")
        self.assertEqual(client.eae_backend_url, "https://my.domain.com")

    def test_removes_leading_and_trailing_slashes_from_app(self, m):
        m.return_value.json.return_value = {"next": None, "results": [42, 24]}
        client = EaeApiClient("https://my.domain.com/")
        client.get_list("/myapp/", "myendpoint")
        m.assert_called_once_with(
            "https://my.domain.com/myapp/api/v1/myendpoint/", headers={}, params={}
        )

    def test_removes_leading_and_trailing_slashes_from_endpoint(self, m):
        m.return_value.json.return_value = {"next": None, "results": [42, 24]}
        client = EaeApiClient("https://my.domain.com/")
        client.get_list("myapp", "/myendpoint/")
        m.assert_called_once_with(
            "https://my.domain.com/myapp/api/v1/myendpoint/", headers={}, params={}
        )


@patch("eae_api_client.eaeapiclient.requests.get")
class GetItemTestCase(TestCase):
    def setUp(self):
        self.eae_api_client = EaeApiClient("https://mydomain.com")

    def test_returns_correct_result(self, m):
        m.return_value.json.return_value = {"one": 1, "two": 2}
        item = self.eae_api_client.get_item("myapp", "myendpoint")
        self.assertEqual(item, {"one": 1, "two": 2})

    def test_makes_get_request(self, m):
        m.return_value.json.return_value = {"one": 1, "two": 2}
        self.eae_api_client.get_item("myapp", "myendpoint")
        m.assert_called_once_with(
            "https://mydomain.com/myapp/api/v1/myendpoint/", headers={}, params={}
        )

    def test_raises_on_error(self, m):
        m.return_value.raise_for_status.side_effect = requests.RequestException()
        with self.assertRaises(requests.RequestException):
            self.eae_api_client.get_item("myapp", "myendpoint")


@patch("eae_api_client.eaeapiclient.requests.put")
class PutTestCase(TestCase):
    def setUp(self):
        self.eae_api_client = EaeApiClient("https://mydomain.com")

    def test_returns_correct_result(self, m):
        m.return_value.json.return_value = {"one": 1, "two": 2}
        item = self.eae_api_client.put("myapp", "myendpoint", data=18)
        self.assertEqual(item, {"one": 1, "two": 2})

    def test_makes_put_request(self, m):
        m.return_value.json.return_value = {"one": 1, "two": 2}
        self.eae_api_client.put("myapp", "myendpoint", data=18)
        m.assert_called_once_with(
            "https://mydomain.com/myapp/api/v1/myendpoint/",
            headers={},
            data=18,
        )

    def test_raises_on_error(self, m):
        m.return_value.raise_for_status.side_effect = requests.RequestException()
        with self.assertRaises(requests.RequestException):
            self.eae_api_client.put("myapp", "myendpoint", data=18)

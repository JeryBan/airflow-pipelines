import json
from unittest import TestCase
from unittest.mock import patch

import requests
from django.conf import settings

settings.configure(DEBUG=False, ALLOWED_HOSTS=["*"])

from django.test import RequestFactory  # NOQA

from eae_api_client import EaeProxyView  # NOQA


@patch("eae_api_client.eaeproxy.View")
class AsViewTestCase(TestCase):
    def setUp(self):
        self._del_eae_backend_url()

    def tearDown(self):
        self._del_eae_backend_url()

    def _del_eae_backend_url(self):
        try:
            delattr(EaeProxyView, "eae_backend_url")
        except AttributeError:
            pass

    def test_sets_eae_backend_url(self, m):
        EaeProxyView.as_view(eae_backend_url="https://mydomain.com")
        self.assertEqual(EaeProxyView.eae_backend_url, "https://mydomain.com")

    def test_removes_trailing_slashes(self, m):
        EaeProxyView.as_view(eae_backend_url="https://mydomain.com//")
        self.assertEqual(EaeProxyView.eae_backend_url, "https://mydomain.com")


class RequestTestCase(TestCase):
    def setUp(self):
        self.eae_proxy_view = EaeProxyView()
        self.eae_proxy_view.eae_backend_url = "https://mydomain.com"
        self.request = RequestFactory().get("/some/path/", secure=True)
        self.eae_proxy_view.request = self.request


@patch("eae_api_client.eaeproxy.requests.request")
class NormalResponseTestCase(RequestTestCase):
    def test_response(self, m):
        m.return_value.json.return_value = {"hello": "world"}
        self.response = self.eae_proxy_view.dispatch(self.request)
        self.assertEqual(self.response.content, b'{"hello": "world"}')

    def test_called_requests_request(self, m):
        m.return_value.json.return_value = {"hello": "world"}
        self.response = self.eae_proxy_view.dispatch(self.request)
        m.assert_called_once_with(
            "GET",
            "https://mydomain.com/some/path/",
            headers={"User-Agent": "Cognitera EaeProxy", "Accept": "application/json"},
            params={},
            data=self.request,
        )

    def test_adds_authorization_header(self, m):
        m.return_value.json.return_value = {"hello": "world"}
        self.request.headers = {"Authorization": "token topsecret"}
        self.response = self.eae_proxy_view.dispatch(self.request)
        m.assert_called_once_with(
            "GET",
            "https://mydomain.com/some/path/",
            headers={
                "Authorization": "token topsecret",
                "User-Agent": "Cognitera EaeProxy",
                "Accept": "application/json",
            },
            params={},
            data=self.request,
        )


class ConnectionErrorResponseTestCase(RequestTestCase):
    @patch("eae_api_client.eaeproxy.requests.request")
    def setUp(self, m):
        super().setUp()
        m.side_effect = requests.RequestException("Connection error")
        self.response = self.eae_proxy_view.dispatch(self.request)

    def test_response_status(self):
        self.assertEqual(self.response.status_code, 502)

    def test_response_content(self):
        data = json.loads(self.response.content.decode("utf8"))
        self.assertIn("Connection error", data["detail"])


class EaeServerReturnsErrorTestCase(RequestTestCase):
    @patch("eae_api_client.eaeproxy.requests.request")
    def setUp(self, m):
        super().setUp()
        m.return_value.status_code = 401
        m.return_value.content = b"hello"
        m.return_value.raise_for_status.side_effect = requests.RequestException
        self.response = self.eae_proxy_view.dispatch(self.request)

    def test_response_status(self):
        self.assertEqual(self.response.status_code, 401)

    def test_response_content(self):
        data = json.loads(self.response.content.decode("utf8"))
        self.assertIn("hello", data["detail"])


class EaeServerResponseUnparsableTestCase(RequestTestCase):
    @patch("eae_api_client.eaeproxy.requests.request")
    def setUp(self, m):
        super().setUp()
        m.return_value.status_code = 200
        m.return_value.content = b"hello"  # Instead of JSON
        m.return_value.raise_for_status.side_effect = requests.RequestException
        self.response = self.eae_proxy_view.dispatch(self.request)

    def test_response_status(self):
        self.assertEqual(self.response.status_code, 502)

    def test_response_content(self):
        data = json.loads(self.response.content.decode("utf8"))
        self.assertIn("hello", data["detail"])


class ReplacePaginationURLsTestCase(RequestTestCase):
    def setUp(self):
        super().setUp()
        self.mock_rr = patch("eae_api_client.eaeproxy.requests.request").__enter__()
        self.mock_rr.return_value.status_code = 200
        self.mock_rr.return_value.json.return_value = {
            "count": 805,
            "previous": "https://mydomain.com/some/path/?page=17",
            "next": "https://mydomain.com/some/path/?page=19",
            "results": "important results",
        }
        self.request.META["SERVER_NAME"] = "myclientdomain.com"
        self.request.META["SERVER_PORT"] = 443

    def tearDown(self):
        self.mock_rr.__exit__()

    def test_response_status(self):
        response = self.eae_proxy_view.dispatch(self.request)
        self.assertEqual(response.status_code, 200)

    def test_previous(self):
        response = self.eae_proxy_view.dispatch(self.request)
        data = json.loads(response.content.decode("utf8"))
        self.assertEqual(
            data["previous"], "https://myclientdomain.com/some/path/?page=17"
        )

    def test_next(self):
        response = self.eae_proxy_view.dispatch(self.request)
        data = json.loads(response.content.decode("utf8"))
        self.assertEqual(data["next"], "https://myclientdomain.com/some/path/?page=19")

    def test_previous_null(self):
        self.mock_rr.return_value.json.return_value["previous"] = None
        response = self.eae_proxy_view.dispatch(self.request)
        data = json.loads(response.content.decode("utf8"))
        self.assertIsNone(data["previous"])

    def test_next_null(self):
        self.mock_rr.return_value.json.return_value["next"] = None
        response = self.eae_proxy_view.dispatch(self.request)
        data = json.loads(response.content.decode("utf8"))
        self.assertIsNone(data["next"])
